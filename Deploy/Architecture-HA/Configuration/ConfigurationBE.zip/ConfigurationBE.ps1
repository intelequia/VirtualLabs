﻿configuration AddDomain 
{ 
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement

    $domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
   
    Node localhost
    {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        WindowsFeature ADPowershell {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        xComputer AddDomain
        {
            Name       = $env:COMPUTERNAME
            DomainName = $domainName
            Credential = $domainCreds
            DependsOn  = "[WindowsFeature]ADPowershell" 
        }
    }
}

configuration RDSDeploy
{
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds,

        # Connection Broker Node name
        [String]$connectionBroker,
        
        # Web Access Node name
        [String]$webAccessServer,

        # Gateway external FQDN
        [String]$externalFqdn,
        
        # Session Host Names
        [String]$numberSessionHost,
        [String]$sessionHostNamePrefix,

        # RD CPU Session Host count and naming prefix
        [Int]$numberOfSessionHostVMsCPU = 0,
        [String]$SHCPUNamingPrefix = "RDSH-CPU-VM",

        # RD GPU Session Host count and naming prefix
        [Int]$numberOfSessionHostVMsGPU = 0,
        [String]$SHGPUNamingPrefix = "RDSH-GPU-VM"
    ) 

    Import-DscResource -ModuleName PSDesiredStateConfiguration -ModuleVersion 1.1
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xRemoteDesktopSessionHost
   
    $localhost = [System.Net.Dns]::GetHostByName((hostname)).HostName

    $username = $adminCreds.UserName -split '\\' | select -last 1
    $domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$username", $adminCreds.Password)

    if (-not $connectionBroker) { $connectionBroker = $localhost }
    if (-not $webAccessServer) { $webAccessServer = $localhost }

    $sessionHostsCPU = ""

    if ($numberOfSessionHostVMsCPU -ne 0) {
        if ($SHCPUNamingPrefix) { 
            $sessionHostsCPU = @( 1..($numberOfSessionHostVMsCPU) | % { "$SHCPUNamingPrefix$_.$domainname"} )
        }
        else {
            $sessionHostsCPU = @( $localhost )
        }
    }

    $sessionHostsGPU = ""

    if ($numberOfSessionHostVMsGPU -ne 0) {
        if ($SHGPUNamingPrefix) { 
            $sessionHostsGPU = @( 1..($numberOfSessionHostVMsGPU) | % { "$SHGPUNamingPrefix$_.$domainname"} )
        }
        else {
            $sessionHostsGPU = @( $localhost )
        }
    }

    if ($sessionHostsCPU -and $sessionHostsGPU) {
        $totalSessionHosts = @($sessionHostsCPU + $sessionHostsGPU)
    }
    elseif ($sessionHostsCPU) {
        $totalSessionHosts = $sessionHostsCPU
    }
    else {
        $totalSessionHosts = $sessionHostsGPU
    }
    

    $collectionName1 = "Default RemoteApp Collection" 
    $collectionDescription1 = "RemoteApp Collection" 

    $collectionName2 = "Default Virtual Host" 
    $collectionDescription2 = "Default Virtual Host"


    Node localhost
    {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        AddDomain AddDomain {
            domainName = $domainName 
            adminCreds = $adminCreds 
        }

        WindowsFeature RSAT-RDS-Tools {
            Ensure = "Present"
            Name = "RSAT-RDS-Tools"
            IncludeAllSubFeature = $true
        }

        Registry RdmsEnableUILog {
            Ensure = "Present"
            Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDMS"
            ValueName = "EnableUILog"
            ValueType = "Dword"
            ValueData = "1"
        }
 
        Registry EnableDeploymentUILog {
            Ensure = "Present"
            Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDMS"
            ValueName = "EnableDeploymentUILog"
            ValueType = "Dword"
            ValueData = "1"
        }
 
        Registry EnableTraceLog {
            Ensure = "Present"
            Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDMS"
            ValueName = "EnableTraceLog"
            ValueType = "Dword"
            ValueData = "1"
        }
 
        Registry EnableTraceToFile {
            Ensure = "Present"
            Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDMS"
            ValueName = "EnableTraceToFile"
            ValueType = "Dword"
            ValueData = "1"
        }

        WindowsFeature RDS-Licensing {
            Ensure = "Present"
            Name = "RDS-Licensing"
        }

        xRDSessionDeployment Deployment
        {
            DependsOn            = "[AddDomain]AddDomain"

            ConnectionBroker     = $connectionBroker
            WebAccessServer      = $webAccessServer

            SessionHosts         = $totalSessionHosts

            PsDscRunAsCredential = $domainCreds
        }


        xRDServer AddLicenseServer
        {
            DependsOn            = "[xRDSessionDeployment]Deployment"
            
            Role                 = 'RDS-Licensing'
            Server               = $connectionBroker

            PsDscRunAsCredential = $domainCreds
        }

        xRDLicenseConfiguration LicenseConfiguration
        {
            DependsOn            = "[xRDServer]AddLicenseServer"

            ConnectionBroker     = $connectionBroker
            LicenseServers       = @( $connectionBroker )

            LicenseMode          = 'PerUser'

            PsDscRunAsCredential = $domainCreds
        }


        xRDServer AddGatewayServer
        {
            DependsOn            = "[xRDLicenseConfiguration]LicenseConfiguration"
            
            Role                 = 'RDS-Gateway'
            Server               = $webAccessServer

            GatewayExternalFqdn  = $externalFqdn

            PsDscRunAsCredential = $domainCreds
        }

        xRDGatewayConfiguration GatewayConfiguration
        {
            DependsOn            = "[xRDServer]AddGatewayServer"

            ConnectionBroker     = $connectionBroker
            GatewayServer        = $webAccessServer

            ExternalFqdn         = $externalFqdn

            GatewayMode          = 'Custom'
            LogonMethod          = 'Password'

            UseCachedCredentials = $true
            BypassLocal          = $false

            PsDscRunAsCredential = $domainCreds
        } 
        
        if ($numberOfSessionHostVMsCPU -ne 0) {

            xRDSessionCollection DefaultRemoteAppCollection
            {
                DependsOn             = "[xRDGatewayConfiguration]GatewayConfiguration"

                ConnectionBroker      = $connectionBroker

                CollectionName        = $collectionName1
                CollectionDescription = $collectionDescription1
            
                SessionHosts          = $sessionHostsCPU

                PsDscRunAsCredential  = $domainCreds
            }

        }
    
        if ($numberOfSessionHostVMsGPU -ne 0) {
            xRDSessionCollection DefaultVirtualHostCollection
            {
                DependsOn             = "[xRDGatewayConfiguration]GatewayConfiguration"

                ConnectionBroker      = $connectionBroker

                CollectionName        = $collectionName2
                CollectionDescription = $collectionDescription2
            
                SessionHosts          = $sessionHostsGPU

                PsDscRunAsCredential  = $domainCreds
            }
        }
    }
}