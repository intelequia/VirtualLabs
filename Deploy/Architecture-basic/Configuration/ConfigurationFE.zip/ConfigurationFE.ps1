configuration AddDomain 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement

    $domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
   
    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        xComputer AddDomain
        {
            Name = $env:COMPUTERNAME
            DomainName = $domainName
            Credential = $domainCreds
            DependsOn = "[WindowsFeature]ADPowershell" 
        }
   }
}

configuration RDFE
{
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds
    ) 


    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        AddDomain AddDomain
        {
            domainName = $domainName 
            adminCreds = $adminCreds 
        }

        WindowsFeature RDS-Gateway
        {
            Ensure = "Present"
            Name = "RDS-Gateway"
        }

        WindowsFeature RDS-Web-Access
        {
            Ensure = "Present"
            Name = "RDS-Web-Access"
        }

        Package UrlRewrite {
            DependsOn = "[WindowsFeature]RDS-Web-Access"
            Ensure    = "Present"
            Name      = "IIS URL Rewrite Module 2"
            Path      = "https://download.microsoft.com/download/C/9/E/C9E8180D-4E51-40A6-A9BF-776990D8BCA9/rewrite_amd64.msi"
            Arguments = "/quiet"
            ProductId = "08F0318A-D113-4CF0-993E-50F191D397AD"
        }
		
		Script ReWriteRules {
            DependsOn  = "[Package]UrlRewrite"
            SetScript  = {
                $site = "iis:\sites\Default Web Site"
                $filterRoot = "system.webServer/rewrite/rules/rule[@name='Redirect base to RDWeb']"
                Clear-WebConfiguration -pspath $site -filter $filterRoot
                Add-WebConfigurationProperty -pspath $site -filter "system.webServer/rewrite/rules" -name "." -value @{name='Redirect base to RDWeb';patternSyntax='Regular Expressions';stopProcessing='True'}
                Set-WebConfigurationProperty -pspath $site -filter "$filterRoot/match" -Name "url" -value "^$"
                Set-WebConfigurationProperty -pspath $site -filter "$filterRoot/conditions" -name "logicalGrouping" -value "MatchAny"
                Set-WebConfigurationProperty -pspath $site -filter "$filterRoot/action" -name "type" -value "Redirect"
                Set-WebConfigurationProperty -pspath $site -filter "$filterRoot/action" -name "url" -value "https://{HTTP_HOST}/RDWeb"
            }
            TestScript = {
                return $false
            }
            GetScript  = { 
                @{ Result = "Success" } 
            }   
        }
    }
}